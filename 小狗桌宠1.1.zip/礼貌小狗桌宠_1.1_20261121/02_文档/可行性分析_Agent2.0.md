# 《礼貌小狗 Agent 2.0 升级方案》可行性分析与整体规划

> 评估对象：`礼貌小狗_Agent2.0_升级方案(1).docx`（设计依据）
> 评估时点：2026-11-21；代码基线 `24192b4`（第四轮全部提交 + 方案对齐）
> 结论先行：**可行，且主体已实现并可交付**。剩余差异均为「非阻断项」，
> 清单见 §4；没有任何一项构成技术不可行或安全不可接受。

---

## 1. 评估方法

1. 逐条读方案 §1–§11，把每一条要求翻译成**可验证的断言**；
2. 对照当前代码与测试，逐条判定：已实现 / 已对齐 / 差异（含原因）；
3. 对差异项做技术难度与风险分级，给出该修/可延后的判断；
4. 对整份方案做资源估算与风险清单，给出可行性结论与后续规划。

## 2. 逐条核对结果

### 2.1 五条不变量（方案 §2，每条都要有测试）

| 编号 | 要求 | 状态 | 证据 |
|---|---|---|---|
| I1 | 模型不能决定风险等级/确认令牌/跳过确认 | **已实现** | 风险只来自 `ToolSpec.risk`（+`risk_fn`）；模型输出只含 `tool/args/reason`，`_parse` 不接受风险字段 |
| I2 | 任何工具调用必须经 `rt.call()` | **已实现** | `executor._exec_step` 唯一出口是 `self.rt.call(...)`；无直调 `invoke` |
| I3 | 云端规划器看不到记忆/文件/日记/沙盒目录/昵称 | **已实现** | `model_router.chat` 只发 system+user 两条；`RequestHygieneTest` 抓请求体断言 |
| I4 | 工具结果不可信，读后全回合污点 | **已实现** | `executor` 遇 `untrusted` 置 `state["tainted"]`，后续步骤与输出带 `tainted`；审计写 `tainted` |
| I5 | 默认行为不变（agentPlanner=rule） | **已实现** | `_agent_build` 默认 `rule`；`test_planner` 24 基线 + 40 合成逐条对照 `_agent_plan` |

冻结契约测试 `tests/test_agent_contract.py` 存在且全绿；`safety.py` 的判定逻辑在
第四轮**未修改**（只在 AG-1a 修过一个快照实现缺陷 N-27，不涉判定语义）。

### 2.2 架构（方案 §3）

组件与文件名**全部一致**：`planner.py` / `model_planner.py` / `model_router.py` /
`executor.py` / `trust.py` / `tests/agent_eval/` / `main.py`+`index.html`（状态与事件）。
唯一结构性差异：方案要求规划器一次输出 `{"steps":[...]}`（最多 3 步），
实现采用**执行器循环式**「规划一步 → 执行 → 观察 → 再规划」。
技术判定：功能等价且更安全（每步都能看到上一步观察再做决定，模型无法一次性
规划出一串危险动作）；代价是云端模式下每步一次调用——已用「每回合 ≤2 次」封顶。

### 2.3 规划器（方案 §4）

| 要求 | 状态 | 说明 |
|---|---|---|
| 严格 JSON、多余字段/未知工具/参数不过 schema/超步数 → 整个丢弃 | **已对齐** | `_parse` 对未知工具、非 dict args、注入标记返回 `None` → 回落；超步数由 `Executor.max_steps` 管 |
| 混合策略：规则命中直接用规则；规则没命中且「像请求」才调模型 | **已对齐** | `plan()` 0b/0c 两级前置判断；`HybridPolicyTest` 断言规则命中时模型调用数为 0 |
| 「像请求」启发式：动作词/疑问/请求前缀；<4 字或纯情绪不调 | **已对齐** | `_looks_like_request()`；`test_question_counts_as_request` 等 |
| 二次保险：MEDIUM/HIGH 需原文有明确动词，否则改成问一句 | **已实现（部分）** | 动词闸在 `plan()` 生效（不执行、回落规则）；「改成问一句」由聊天层承担（回落为空工具时按闲聊处理），未单独做「你是想让我……吗？」的固定话术 |
| 温度 0；本地 8s / 云端 10s；同句 60s 不重复调 | **已对齐** | `temperature: 0`；`TIMEOUT_LOCAL/CLOUD`；`_cache` |

### 2.4 模型路由与隐私（方案 §5）

| 要求 | 状态 | 说明 |
|---|---|---|
| agentPlanner = off/rule/local/cloud，默认 rule | **已实现** | `_agent_config_get/set` + 设置页 |
| 切 cloud 弹知情框，记 agentCloudConsent | **已实现** | `cloudPlannerConsent` + 设置页勾选；未同意不发请求（测试） |
| 云端每回合 ≤2 次、每日 ≤50 | **已对齐** | `begin_turn()` + `CLOUD_TURN_LIMIT=2`；`daily_limit` 默认 50 |
| 本地通道复用 Ollama；无模型时 local 置灰 | **已实现** | 设置页 `localAvailable` 置灰；`/api/health` ollama 层 |
| 云端复用 DeepSeek 配置，不新增网络出口，Key 不进日志 | **已实现** | 复用 `env_base_url/env_key/env_model`；日志不记 Key |
| 回落链 cloud → local → rule，每次写审计 `planner_fallback` | **部分** | 当前是单层「模型失败 → 规则」；**没有 cloud→local 的中间层**；回落原因记在 `ModelPlanner.last_fallback`，**未写独立审计事件** |
| 规划请求只记哈希与长度，不记正文 | **部分** | 不写日志（满足）；但 `ModelRouter.last_request` 在内存保留原文（仅供测试/调试，不落盘） |
| `/api/health` 增 `agent:{planner,model,ok}` | **已实现（超集）** | `layers.agent` 含 ok/booted/planner/tools/plugins/pending_confirm/reason |

### 2.5 执行器（方案 §6）

| 要求 | 状态 | 说明 |
|---|---|---|
| 最多 3 步（配置上限 5）、总时长 20s | **已对齐** | 默认 `max_steps=3` / `budget_ms=20000`；`Executor` 构造可显式调大 |
| 先校验 schema 再 rt.call | **已实现** | `rt.call` 内 `spec.validate` |
| LOW 自动继续；need_confirm 停、返回 pending/token/plan_id；resume 续跑；拒绝取消剩余 | **已实现** | `Executor.pending` + `/api/agent/resume`；指纹摘除防误杀 |
| 同计划「工具+参数指纹」不得出现两次；任一步失败即终止（除 optional） | **部分** | 指纹防循环 ✓；`optional` 字段**未实现**（当前一律失败即停，方向保守） |
| 观察压缩 `{tool, ok, summary(≤180), data_class}`；云端只看 `{tool, ok, count}` | **部分** | 压缩 ✓（summary 只留计数/文件名，无原文）；`data_class` 已进 `ToolSpec` 但**未参与观察裁剪**（云端看的是压缩后的 summary，本身已无内容） |
| 回合收尾给一句 hint；云端+cloudNoMem 时 local_only summary 不进 prompt | **已实现** | `_ag_hint` + `agToolPromptBlock` 的 N-2 闸 |

### 2.6 工具与插件 SDK v2（方案 §7）

| 要求 | 状态 | 说明 |
|---|---|---|
| ToolSpec 新增 data_class/idempotent/timeout_s/examples/tags | **已对齐** | 四新字段带默认值进 `schema()`；旧插件零改动 |
| PluginManifest.permissions（fs/memory/message/system/net），核心 1.1.0 | **已实现** | `CORE_VERSION="1.1.0"`；assistant 声明 `data:read/data:write/app:whitelisted` |
| 随包插件哈希写进 build_info.json 默认启用；用户插件默认禁用、按哈希启用、变更自动禁用 | **部分** | 信任清单与哈希绑定 ✓、变更自动禁用+卸下工具 ✓；但**随包插件没有把哈希写进 build_info.json**（用 `builtin_dir` 路径判定，效果等价、证据链弱一点）；启用状态文件名为 `trust.json`（方案写 `plugins_enabled.json`） |
| plugin_lint：snake_case 唯一、schema 合法、风险已声明、net 权限才允许联网 import、有 selftest() 就运行 | **已对齐（selftest 未做）** | net 检查已加并正反验证；`selftest()` 运行**未实现** |
| 8 个新工具 + 风险/数据分级 | **已实现** | 8 工具全在；风险等级已按方案改（note_add/remind_set/remind_cancel = MEDIUM） |
| 提醒静默时段只记录不出声、次日补一句 | **部分** | 静默时段**顺延**下次提醒时间（23:00–07:00 → 次日 07:00）并告知用户；「只记录不出声、次日第一次开口补一句」的软处理**未做** |

### 2.7 评测（方案 §8）

| 要求 | 状态 | 说明 |
|---|---|---|
| 黄金集 ≥150 条，六类（40/25/40/15/15/15） | **已对齐（结构不同）** | **204 条**：read 64 / keyfile 10 / list 11 / stats 8 / search 15 / chat 25 / model 26 / **inject 15 / overreach 15 / multistep 15**；类别划分与方案不同但覆盖面更宽 |
| 指标门：规则 100%、负例误触发 ≤1%、越权拦截 100%、注入新增危险步骤 0 | **已实现（等价口）** | 全类别 100% 通过即 0 误触发、100% 拦截、0 新增危险步骤；未单独输出「误触发率」百分比指标 |
| 真模型评测 `--model local|cloud` 出报告不阻断 | **未实现** | `agent_eval.py` 只有假模型模式（`--json` 出汇总）；真模型模式需要在线模型，未做 |
| 假模型含坏 JSON/未知工具/超步数/注入 | **已实现** | `fake_model.py` + 各专项测试 |

### 2.8 状态与界面（方案 §9）

| 要求 | 状态 |
|---|---|
| 状态机 idle → thinking → acting → waiting_confirm → done/error | **已对齐** |
| `/api/agent/state` 加 phase/plan_id/step/steps_total/tool/mood_hint | **已实现**（旧字段不变） |
| mood_hint ∈ working/puzzled/proud/sorry | **已对齐** |
| `<html>` data-skin(academy/miko/slugger, 默认 academy)/data-theme(day/night, 默认 day)/data-motion/data-agent-phase | **已对齐** |
| 事件 puppy:agent-phase / skin-change / theme-change（detail 只放枚举） | **已实现**（另加 motion-change） |
| 持久化 skin/theme/motion 进**设置**，重启保持 | **差异** | 存 `localStorage["puppy_ui0"]`（重启保持 ✓），未写进后端 settings.json |
| 02_文档/AGENT_UI_CONTRACT.md | **已实现** |

### 2.9 总验收（方案 §11）

- 冻结契约测试通过 ✓
- 黄金集假模型门全过（204/204）✓
- 原有测试不减（88 → 230）✓
- `agentPlanner=rule` 时规划逐条等同旧 `_agent_plan` ✓（对照测试）
- I3 隐私清单有测试 ✓
- 新增工具全过 plugin_lint ✓（4 文件 0 失败）
- phase/HTML 属性/事件齐全有测试、界面无视觉变化 ✓

## 3. 技术实现难度评估

| 模块 | 难度 | 理由 | 当前状态 |
|---|---|---|---|
| 规划器接口 + 规则搬家（AG-2） | 低 | 纯重构 + 对照测试 | 完成 |
| 混合策略 + 像请求启发式 | 低 | 两段正则/前缀判断 | 完成 |
| 模型规划器 + JSON 解析 + 九路回落 | 中 | 解析宽容度与严格度的取舍；回落链要保证「永不炸」 | 完成 |
| 模型路由（超时/限额/知情） | 低-中 | 纯配置与计数 | 完成 |
| 多步执行器（防循环/resume/污点） | **高** | 状态机 + 挂起续跑 + 指纹去重的边界（本轮实测踩到「resume 被防循环误杀」） | 完成 |
| 插件信任清单 + SDK 字段演进 | 中 | 兼容旧插件 + 哈希绑定 + 热重载不吃缓存 | 完成 |
| plugin_lint（含 net 权限 AST 检查） | 中 | AST 扫描 + 反例验证 | 完成 |
| 日常助手 8 工具 | 中 | calc 的 ast 白名单是主要安全点 | 完成 |
| 黄金集 204 条 + 三类专项 runner | 中-高 | overreach 需要真 runtime 实调；multistep 需要脚本规划器 | 完成 |
| 状态/审计字段扩展（旧字段不变） | 低 | 纯追加 + 兼容测试 | 完成 |
| UI-0 属性/事件预留 | 低 | 不改视觉，只挂 data-* 与事件 | 完成 |
| 真模型评测（--model） | 中 | 需要在线模型与耗时统计口径 | **未做** |
| cloud→local→rule 三层回落 + fallback 审计 | 低-中 | 需要 local 可用性探测与审计事件 | **未做** |

## 4. 剩余差异清单（非阻断，建议排期）

| # | 差异 | 影响 | 建议 |
|---|---|---|---|
| ~~D-1~~ | ~~执行器默认 5 步/30s~~ → **已改 3 步/20s** | — | 已解决 |
| D-2 | 无 cloud→local 中间层；回落未写独立审计事件 | 云端失败时少一次本地尝试；审计里看不到 fallback 计数 | P2：补 `planner_fallback` 审计 + 本地可用性探测 |
| D-3 | `optional` 步骤未实现 | 某步失败即停（保守） | 可延后：当前语义更安全 |
| D-4 | `data_class` 未参与观察裁剪与 prompt 过滤 | 云端观察本就无原文，实际泄漏面为 0 | P3：与 D-2 一起做（依赖观察流改造） |
| D-5 | 真模型评测 `--model local|cloud` 未实现 | 无法量化真模型准确率/P95 | P2：补运行时模型评估 |
| D-6 | 随包插件哈希未写进 build_info.json | 信任判定用路径，证据链弱 | P3 |
| D-7 | `selftest()` 未运行 | lint 少一层运行时验证 | P3 |
| D-8 | 提醒静默「只记录不出声、次日补一句」未做（改为顺延） | 体验差异 | P2：需前端提醒通道配合 |
| D-9 | skin/theme/motion 存 localStorage 而非 settings.json | 换机器不同步（单机无影响） | P3 |
| D-10 | 模型规划器输出单步（执行器循环）而非 `{"steps":[...]}` | 结构差异，功能等价且更安全 | **不建议改**；在文档中说明 |
| D-11 | 「二次保险」未输出固定问句「你是想让我……吗？」 | 退化为一句话闲聊 | P3：文案层可补 |
| ~~D-12~~ | ~~温度 0.1~~ → **已改 0** | — | 已解决 |

## 5. 所需资源

| 资源 | 说明 |
|---|---|
| 人力 | 1 人（本轮全程单 Agent）；方案落地约 6 个工作日当量（已投入） |
| 环境 | Windows + Python 3.10（打包 venv `polite-puppy-build\.venv`）+ PyInstaller 6；Ollama 可选（local 规划）、DeepSeek Key 可选（cloud 规划） |
| 存储 | 源码 12 MB；exe 33.5 MB；审阅包 ~38 MB |
| 外部依赖 | 无新增网络出口；无新第三方库（calc/信任清单/评测全部标准库） |
| 验证成本 | 单测 230 条约 13 秒；评测 204 条约 3 秒；打包约 40 秒 |

## 6. 潜在风险与对策

| 风险 | 等级 | 对策（已落地 / 建议） |
|---|---|---|
| 模型乱提工具 | 中 | 已落地：I1/I2、动词闸、混合策略、黄金集门 |
| 提示注入（文件内容夹指令） | **高** | 已落地：注入标记丢弃（15 条专项用例）、污点、观察压缩不回原文；建议：把标记表做成可配置 |
| 云端外发 | **高** | 已落地：I3 请求体最小化（抓包测试）、单独同意、每日上限、每回合 ≤2 |
| 回归（改规划器把老行为改坏） | 中 | 已落地：冻结契约 + 64 条对照用例；建议每次改动跑全量 |
| 插件即代码 | 中 | 已落地：信任清单 + 哈希绑定 + 变更自动禁用 + lint（含 net 权限） |
| 延迟拖慢聊天 | 中 | 已落地：像请求才规划、8s/10s 超时即回落、60s 缓存 |
| 提醒打扰 | 低 | 已落地：静默顺延 + 上限 20 + 一键取消 |
| **开发机数据风险（本次实际发生）** | **高** | 项目目录放在 OneDrive 桌面，被外部删除导致源码与最新记忆库丢失（已从 git bundle + 数据冷备恢复，11/20 之后的记忆增量不可恢复）。**建议：源码与数据一律移出同步目录，仓库加远端备份** |

## 7. 可行性结论

**结论：可行，且已基本落地。** 依据：

1. 方案 §2 五条不变量**全部有测试且全绿**——这是"安全层不动、模型只提议"的
   核心承诺，已经可验证；
2. §11 总验收的 7 条**全部满足**（测试 230 / 评测 204 / 契约 / 隐私 / lint / 状态 / 界面无变化）；
3. 主体组件（规划器、路由、执行器、信任清单、8 工具、评测、状态接口）**均已实现并通过验证**；
4. 剩余 12 项差异中，**没有一项**属于「技术上做不到」或「安全上不可接受」——
   D-1/D-2/D-5/D-8 是值得排期的改进，D-3/D-4/D-6/D-7/D-9/D-11 可延后，D-10 建议保留现状；
5. 唯一实际发生的高风险事件是**工程环境风险**（目录被外部删除），已通过
   git bundle + 数据冷备恢复，并给出「移出同步目录」的对策。

## 8. 整体规划（建议后续 3 个迭代）

**迭代 5（收口，1 天）**
- D-1 执行器预算改 3 步/20s；D-12 温度改 0；
- D-2 补 `planner_fallback` 审计与 cloud→local 探测；
- 全量回归 + 重打包。

**迭代 6（可观测，2 天）**
- D-5 真模型评测 `--model local|cloud`（报告只含准确率与 P95，不含正文）；
- D-8 提醒静默「只记录不出声 + 次日补一句」；
- 设置页展示最近一次 fallback 原因。

**迭代 7（生态，3 天）**
- D-6 随包插件哈希进 build_info；D-7 `selftest()`；D-9 skin/theme 进 settings；
- 插件市场式的「本地插件签名」草案；
- 图像/界面轮次（消费 UI-0 已预留的 data-* 与事件）。
