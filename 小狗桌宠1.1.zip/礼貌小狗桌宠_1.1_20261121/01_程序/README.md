# 礼貌小狗

Windows 桌面 AI 伴侣。透明无边框立绘 + 仿微信聊天窗，默认用**包内本地大脑**跑，
**不联网、不上传**；接本机 Ollama 也全程不出这台电脑。

**"不联网"只对本地 / 本机大脑成立。** 只有你自己填了云端接口的地址和 Key、
并且切到「云端」之后，聊天内容才会发到那台接口；第一次切过去会弹一次知情提示，
写清楚会发什么（设置 → 参数 里「当前模式」那行也一直标着现在是本地还是云端）。
云端模式下默认**不带记忆片段**，想连旧事一起发才需要自己关掉那个开关。

> 她不是"一问一答"的客服。她会连发三条、会发表情包、会自己画图，
> 会在你三分钟不说话的时候主动找你。

**普通用户请直接看 `使用说明.txt`**，这份是技术说明。

**本包自检基线**：测试 `230` 条全过；外发包 `123` 个文件；
exe SHA256 前 16 位 `25f6b63eebd7437b`（完整值见 `03_校验/MANIFEST.json`）。
三个数字由发布脚本组装时填入——源码里是占位符，不是手抄的死数。

---

## 目录结构（与实物一致）

```
礼貌小狗桌宠_最新版_20261029/
├─ 00_先看这个.md          交付说明
├─ 01_程序/
│  ├─ PolitePuppy.exe      主程序（PyInstaller onefile，需按源码重新打包）
│  ├─ main.py              窗口 / 托盘 / 热键 / 本地 HTTP / 代理 / 语音（源码）
│  ├─ index.html           聊天 UI + 全部前端逻辑（单文件，无构建）
│  ├─ local_brain.py       本地大脑（brain.json 语料 + 打分选句）
│  ├─ puppy_core.py        Agent 核心
│  ├─ puppy_agent/         Agent 插件与运行时
│  ├─ tools/               运行期才 import 的工具模块（音色、记忆抽取、F5 网关）
│  ├─ scripts/             发布打包 / 记忆库脱敏（不参与运行）
│  ├─ tests/               冒烟测试（python tests\run_tests.py）
│  ├─ voices/              音色档案（profiles/ + active.json + voice_id.json）
│  ├─ 记忆/memory.db       SQLite 记忆库（首次启动自动创建，不在外发包里）
│  ├─ 表情包/              内置表情图
│  ├─ brain.json           本地大脑语料
│  ├─ persona.json         人设
│  ├─ .env.example         配置模板（复制成 .env 再填）
│  ├─ .env                 你的实际配置（含 Key，永远不要外发）
│  └─ run.bat              源码模式启动
├─ 02_文档/                设计与修复说明
└─ 03_校验/                SHA256.txt + MANIFEST.json（由发布脚本自动生成）
```

## 跑起来

**方式 A：直接用 exe（推荐）**

双击 `01_程序/PolitePuppy.exe`。不需要 Python、不需要构建。

**方式 B：源码跑**

```powershell
cd 01_程序
py -3.10 -m pip install -r requirements.txt
python main.py
```

需要 **Python 3.10.x**（3.11/3.12 未验证）。依赖分两份：

| 文件 | 装什么 | 什么时候要 |
|---|---|---|
| `requirements.txt` | pywebview / pystray / Pillow / python-pptx / pythonnet | 源码模式必装 |
| `requirements-voice.txt` | torch / torchaudio / numpy / soundfile / omegaconf / hydra-core（+ 官方仓库的 F5-TTS） | 只有跑克隆音色才装 |

装完可以跑一遍自检：`python tests\run_tests.py`（不需要联网，会起一个临时端口的服务）。

源码模式读的是同一份 `main.py` / `index.html`，行为与 exe 一致。

**接外部大模型（可选）**

```powershell
ollama serve
ollama pull qwen2.5:7b
```

然后在「设置 → 模型」里填 `127.0.0.1:11434` 和 `qwen2.5:7b`。

> 别用 `localhost`：WebView2 有时解析到 `::1`，Ollama 只听 `127.0.0.1`，会连不上。

## 数据位置

**记忆库 / 日记 / Agent 日志**在数据目录，默认 `%LOCALAPPDATA%\PolitePuppyPet\data`
（可用环境变量 `POLITE_PUPPY_DATA` 改）。**音色和表情**跟程序放一起。

| 路径 | 内容 |
|---|---|
| `%LOCALAPPDATA%\PolitePuppyPet\data\记忆\memory.db` | 记忆库（聊天记录、事实、关系），SQLite + FTS5 trigram |
| `%LOCALAPPDATA%\PolitePuppyPet\data\memory_diary.txt` | 日记，一行一件事，可直接编辑，首次启动自动生成模板 |
| `%LOCALAPPDATA%\PolitePuppyPet\data\agent_data\` | Agent 审计日志、快照回收站、沙盒工作区 |
| `01_程序\voices\` | 音色档案与克隆样本 |
| `01_程序\.voice_cache\` | TTS 缓存，可删，自动重建 |
| `01_程序\plugins\` | Agent 插件 |

为什么不放 exe 旁边：交付包常在 `OneDrive\Desktop` 下，SQLite 的 `-wal`/`-shm`
一边写一边被云盘同步，有损坏风险；而且重装/换目录就丢记忆。
老版本放在 `01_程序\记忆\` 的数据，第一次启动会**拷**一份到新目录（原件不动）。

备份 = 复制 `data` 目录 + `voices` 目录。卸载 = 删程序目录 + `%LOCALAPPDATA%\PolitePuppyPet`。

## 什么会出这台电脑

| 模式 | 会不会外发 | 发什么 |
|---|---|---|
| 本机大脑 | 不会 | — |
| 本地（Ollama，127.0.0.1） | 不会 | — |
| 演示 | 不会 | — |
| 云端（远程 API） | **会** | 你说的话、她的回复、系统提示词（人设 / 口癖 / 今天日志 / 系统内置的表情包名单），发图时附带的图片描述 |

云端模式下默认**不带**检索到的记忆片段和日记片段（「云端模式不带记忆片段」默认开，
设置 → 人设 里可改）。关掉它才会把旧事一起发出去。

两种容易忽略的情况：

- **切到云端后，聊天窗口里已经存在的历史消息会随这一轮请求发出去**——
  即使你打开了"云端模式不带记忆片段"，那条限制只挡**记忆库检索结果**和
  日记片段，挡不住聊天框里你此前打过的旧内容。介意的话切云端前先清空聊天窗；
- Agent 工具查到的文件内容属于 system prompt 的一部分，云端模式下同样会发出去——
  不想外发就别在云端模式里让她读文件；
- 图片走的是本机解析（`describe_image`），不上传原图，只把一句话的描述拼进 prompt。

### 私人词表（不进版本库、不进发布包）

扫描器需要知道"哪些词是你们的称呼"才能拦住外发。本机配置二选一：
环境变量 `PUPPY_PRIVATE_NAMES`（逗号分隔）或
`01_程序\private_names.local.txt`（一行一个，`#` 开头是注释）。
两者都不入库、不进发布包（`pack_check --release` 词表为空直接 FAIL）。
词表自动派生 Windows 8.3 短名（前 6 字符 + `~1`）一起查。

### 备份保留

记忆库补列迁移前、以及 replace 模式导入前，都会先用 SQLite 一致性备份接口
把真实库复制到 `记忆\backup\`，文件名带版本号与时间戳，**保留最近 3 份**，
每份约等于当时 memory.db 的大小（通常几 MB）。想手动回滚直接拷回去即可。

## 架构

1. `main.py` 起一个只监听 `127.0.0.1` 的 `http.server`（端口从 8765 起找空位），
   把 `index.html`、立绘、表情包和 `/api/*` 一起发出去；
2. pywebview 加载 `http://127.0.0.1:端口/`，所以 `fetch('/api/chat')` 是同源请求，没有预检；
3. 代理层把请求转给后端模型，SSE 用 chunked 原样透传，前端逐字接收；
4. 真出现 `file://` 场景（直接双击 html），`onAPIError` 自动改调 `pywebview.api.chat()`。

安全：`Host` / `Origin` / `Sec-Fetch-Site` 三重校验，跨站与 DNS rebinding 一律 403；
`.env`、`main.py`、`记忆/memory.db` 等敏感路径全部 404；
`/api/*` 还要带 `X-Puppy-Token`——每个进程随机一把，只通过 pywebview 的桥注入前端，
**不写进 HTML**（写进去等于把钥匙挂在门上），所以本机别的进程 curl 过来只会拿到 401。

## 标签协议（System Prompt 已写死）

```
咋了||谁惹你了||说          → 三个气泡，一条条蹦
[STICKER:无语]              → 表情包气泡（名字必须和你传过的完全一致）
[DRAW:a girl eating noodles, anime style] → 生图气泡，英文描述
[QUICK:说说,不想说]          → 不显示成气泡，只换底部快捷回复
```

前端容错：`【】`、`：`、`｜｜` 等全角符号都能认；认不出的表情包名退化成一句灰字，不会崩。

## 打包

需要 **Python 3.10**（3.11+ 的 pythonnet 在 Windows 上装不稳），并装好
`requirements.txt` 与 PyInstaller。一键脚本：

```powershell
# 1) 打包 + 写 build_info + 自检（31 项）
powershell -ExecutionPolicy Bypass -File scripts\build_exe.ps1

# 2) 把 dist\PolitePuppy.exe 和 dist\build_info.json 拷回 01_程序
# 3) 按白名单组装外发包（自动排除 记忆/、我的声音、.env，并扫用户名）
python scripts\package_release.py --with-exe --out ..\发布_v1
python scripts\package_release.py --check ..\发布_v1
```

- `scripts\PolitePuppy.spec` 是打包配置：`puppy_agent` 以数据目录再拷一份（插件运行期按路径加载），
  `tools\` 与 `表情包\` 不打进 exe（程序按 exe 旁边那份找）。
- `build_info.json` 记录版本 + `main.py` / `index.html` 哈希 + exe 哈希。
  **不要用"在 exe 里搜版本号"判断新旧**——onefile 的 pyc 是压缩的，搜不到不代表旧包。

**为什么必须显式 `--hidden-import`**：`tools/` 下的模块和 `memory_organize.py` 是
运行期才 import 的，PyInstaller 静态分析扫不到；不写进去，打出来的 exe 会缺模块，
表现是"某个功能悄悄失效"（语音哑了、记忆抽不出事实），而且不报错。
原文档里的 `dev/build.ps1` / `dev/pack_check.py` 从来没进过包，已由 `scripts/` 取代。

## 已知限制

- 单实例：同一时间只能跑一只，重复启动会唤回已有实例并提示版本；
- 记忆检索：`FTS_MIN_LEN = 3`，1~2 字查询走 `LIKE '%词%'`，记忆量很大时会变慢；
- 本地大脑：语料有限，复杂问题答不好，接外部模型明显更好；
- 语音识别依赖 Web Speech 或系统 SAPI，两者都没有时会提示"打字吧"。

更细的待办见 `02_文档/后续开发建议.md`。
