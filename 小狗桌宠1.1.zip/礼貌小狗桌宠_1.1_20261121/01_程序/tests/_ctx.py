# -*- coding: utf-8 -*-
"""测试公共准备：把数据目录指到临时目录，再 import main。

⚠ 顺序很重要：main 在 import 时就会算 DATA_DIR / LOG_FILE / CONFIG_FILE。
先设 POLITE_PUPPY_DATA，再 import，测试才不会往真的 %APPDATA% 和记忆库里写东西。
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

PROG = Path(__file__).resolve().parent.parent
if str(PROG) not in sys.path:
    sys.path.insert(0, str(PROG))

TMP = Path(tempfile.mkdtemp(prefix="puppy_test_"))
os.environ["POLITE_PUPPY_DATA"] = str(TMP / "appdata")

import main  # noqa: E402  （必须在设置环境变量之后）

# 记忆库 / 日记 / 日志 / 配置全部搬进临时目录
main.MEMORY_DIR = TMP / "记忆"
main.MEMORY_DB = main.MEMORY_DIR / "memory.db"
main.MEMORY_ORGANIZE_STATE = main.MEMORY_DIR / "organize_state.json"
main.DIARY_FILE = TMP / "memory_diary.txt"
main.LOG_FILE = TMP / "pet.log"
main.CONFIG_FILE = TMP / "settings.json"
main.DATA_DIR = TMP / "appdata"
main._MEM_INITED = False
main.setup_logging(False)

AGENT_DATA = TMP / "agent_data"
# N-19：完整数据目录层——真实环境是 data_dir()（记忆/日记/agent_data 的上一级），
# 测试里这几样都直接铺在 TMP 下，所以 TMP 就是它的等价物。
DATA_ROOT = TMP


def api_token() -> str:
    """P1-5 之后 /api/* 要带令牌；没这机制时返回空串，测试照样能跑。"""
    return str(getattr(main, "API_TOKEN", "") or "")


def api_headers(extra: dict | None = None) -> dict:
    out = {}
    token = api_token()
    if token:
        out["X-Puppy-Token"] = token
    out.update(extra or {})
    return out
