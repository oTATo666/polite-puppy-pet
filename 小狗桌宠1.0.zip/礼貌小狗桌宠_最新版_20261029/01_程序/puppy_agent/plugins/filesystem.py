# -*- coding: utf-8 -*-
"""
插件：文件工具
==============

真实可用的文件操作能力。风险分级严格按"读 / 写 / 删"区分，
删除走快照 + 高风险确认。
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

from ..core.plugin import Plugin, PluginManifest, RiskLevel, ToolSpec

# 只允许操作的目录（防止乱跑）。默认为用户主目录与常见工作区。
ALLOW_ROOTS_ENV = "PUPPY_AGENT_ALLOW_ROOTS"


def _allowed_roots(ctx) -> list:
    raw = (ctx.config or {}).get("allow_roots") or os.environ.get(ALLOW_ROOTS_ENV) or ""
    roots = [Path(p) for p in raw.split(os.pathsep) if p.strip()]
    if not roots:
        roots = [Path.home()]
    out = []
    for r in roots:
        try:
            out.append(r.expanduser().resolve())
        except OSError:
            continue
    return out


def _check_path(ctx, path: str) -> tuple:
    """检查路径是否在允许范围内。返回 (Path, 错误信息)。"""
    try:
        p = Path(path).expanduser().resolve()
    except OSError as exc:
        return None, "路径无效：%s" % exc
    for root in _allowed_roots(ctx):
        try:
            p.relative_to(root)
            return p, ""
        except ValueError:
            continue
    return p, "超出允许范围：%s（允许：%s）" % (
        p, "、".join(str(r) for r in _allowed_roots(ctx)))


class FileToolsPlugin(Plugin):
    manifest = PluginManifest(
        id="filesystem",
        name="文件工具",
        version="1.0.0",
        description="本机文件的读取、列表、搜索、写入与删除（删除有快照可回滚）",
    )

    def setup(self, ctx) -> None:
        self.ctx = ctx

    def tools(self) -> list:
        return [
            ToolSpec(
                name="fs_read",
                description="读取一个文本文件的内容（只读）",
                risk=RiskLevel.LOW,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string",
                                 "description": "文件的绝对路径"},
                        "max_chars": {"type": "integer",
                                      "description": "最多返回多少字符，默认 4000"},
                    },
                    "required": ["path"],
                },
                invoke=self._read,
                tags=["文件", "只读"],
            ),
            ToolSpec(
                name="fs_list",
                description="列出某个目录下的文件（只读）",
                risk=RiskLevel.LOW,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string",
                                 "description": "目录的绝对路径"},
                        "max_items": {"type": "integer",
                                      "description": "最多返回多少项，默认 100"},
                    },
                    "required": ["path"],
                },
                invoke=self._list,
                tags=["文件", "只读"],
            ),
            ToolSpec(
                name="fs_write",
                description="写入或覆盖一个文本文件（会改掉原内容）",
                risk=RiskLevel.MEDIUM,
                destructive=True,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string",
                                 "description": "文件的绝对路径"},
                        "content": {"type": "string",
                                    "description": "要写入的文本内容"},
                        "append": {"type": "boolean",
                                   "description": "true 表示追加，false 表示覆盖"},
                    },
                    "required": ["path", "content"],
                },
                invoke=self._write,
                tags=["文件", "写"],
            ),
            ToolSpec(
                name="fs_delete",
                description="删除一个文件或目录（破坏性，执行前会先做快照）",
                risk=RiskLevel.HIGH,
                destructive=True,
                snapshot=True,
                parameters={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string",
                                 "description": "要删除的文件或目录的绝对路径"},
                    },
                    "required": ["path"],
                },
                invoke=self._delete,
                tags=["文件", "删除"],
            ),
        ]

    # ------------------------------------------------------------- 具体实现
    def _read(self, args: dict) -> dict:
        p, err = _check_path(self.ctx, args.get("path", ""))
        if err:
            return {"ok": False, "message": err}
        if not p.is_file():
            return {"ok": False, "message": "文件不存在：%s" % p}
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return {"ok": False, "message": "读取失败：%s" % exc}
        limit = int(args.get("max_chars") or 4000)
        clipped = text[:limit]
        return {"ok": True, "path": str(p), "chars": len(text),
                "truncated": len(text) > limit, "content": clipped}

    def _list(self, args: dict) -> dict:
        p, err = _check_path(self.ctx, args.get("path", ""))
        if err:
            return {"ok": False, "message": err}
        if not p.is_dir():
            return {"ok": False, "message": "不是目录：%s" % p}
        limit = int(args.get("max_items") or 100)
        items = []
        try:
            for child in sorted(p.iterdir(), key=lambda x: x.name):
                try:
                    size = child.stat().st_size
                    is_dir = child.is_dir()
                except OSError:
                    size, is_dir = 0, False
                items.append({"name": child.name, "dir": is_dir, "size": size})
                if len(items) >= limit:
                    break
        except OSError as exc:
            return {"ok": False, "message": "列目录失败：%s" % exc}
        return {"ok": True, "path": str(p), "count": len(items), "items": items}

    def _write(self, args: dict) -> dict:
        p, err = _check_path(self.ctx, args.get("path", ""))
        if err:
            return {"ok": False, "message": err}
        content = args.get("content") or ""
        append = bool(args.get("append"))
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            if append and p.is_file():
                with open(p, "a", encoding="utf-8") as f:
                    f.write(content)
            else:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(content)
        except OSError as exc:
            return {"ok": False, "message": "写入失败：%s" % exc}
        return {"ok": True, "path": str(p), "bytes": len(content.encode("utf-8")),
                "append": append}

    def _delete(self, args: dict) -> dict:
        p, err = _check_path(self.ctx, args.get("path", ""))
        if err:
            return {"ok": False, "message": err}
        if not p.exists():
            return {"ok": False, "message": "路径不存在：%s" % p}
        # 兜底：不允许删整个盘根
        if str(p) in ("/", "C:\\", "C:/") or len(p.parts) <= 2:
            return {"ok": False, "message": "拒绝删除这么危险的位置：%s" % p}
        try:
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
        except OSError as exc:
            return {"ok": False, "message": "删除失败：%s" % exc}
        return {"ok": True, "path": str(p), "deleted": True}
