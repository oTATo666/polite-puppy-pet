# -*- coding: utf-8 -*-
"""礼帽小狗 · Agent 插件包。

每个 .py 文件是一个独立插件，运行时扫描目录自动加载。
插件要实现 Plugin 子类 + manifest + tools()。
"""

__all__ = []
