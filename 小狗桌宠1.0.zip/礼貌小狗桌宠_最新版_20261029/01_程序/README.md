# 礼貌小狗 · 千逐（本地 Ollama 桌宠）

Windows 桌面 AI 伴侣。透明无边框立绘 + 仿微信聊天窗，大脑是**本机 Ollama**，不上传任何东西。

> 她不是"一问一答"的客服。她会连发三条、会发表情包、会自己画图、会在你三分钟不说话的时候主动找你。

## 这一版新加的东西

| 模块 | 说明 |
|---|---|
| 语音输入 | 输入框左侧麦克风。优先 Web Speech（中文流式），不可用时自动切 Windows 自带识别（SAPI）；录音时红色呼吸灯 |
| 动态快捷回复 | 模型输出 `[QUICK:a,b]`，底部标签条自动换成这几个，点一下直接当用户输入发出去 |
| 多气泡队列 | 按 `\|\|` 拆条，每条 0.5~1.3 秒，期间显示"对方正在输入…"+三个点 |
| 表情包 | IndexedDB 存图（设置 → 表情），模型输出 `[STICKER:名字]` 渲染成图片气泡 |
| 生图 | `[DRAW:english prompt]` → 先显示"千逐正在画画…"骨架屏，预加载好再换成图片 |
| 记忆 RAG | 每次请求前读 `memory_diary.txt`，按关键词（中文二元组）打分取 3 条 + 最近 2 条塞进 System Prompt |
| 冷场唤醒 | 3 分钟没对话自动发隐藏 Prompt（不显示成用户气泡），她主动开腔 |
| 跨域 | 全部走本机 `127.0.0.1` 同源代理；`file://` 打开时自动降级到 `pywebview.api.chat` 桥 |

## 跑起来

**最省事**：解压后双击 `放到桌面并建快捷方式.bat` —— 自动把项目复制到桌面 `礼貌小狗桌宠\`、生成带小狗图标的 `礼貌小狗.lnk` 快捷方式，还会问你一句要不要开机自启。以后桌面双击 `礼貌小狗` 就启动。

手动方式：

```powershell
# 1. 大脑
ollama serve
ollama pull qwen2.5:7b

# 2. 依赖
py -3.10 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt

# 3. 启动
.\.venv\Scripts\python.exe main.py
```

点立绘开聊天。右键立绘或托盘里改大小 / 置顶 / 自启。对话不占全局快捷键；
语音相关的四个热键（输出 / 暂停 / 停止 / 麦克风）在「设置 → 键位」里可自定义。

聊天窗齿轮 → 连接，可以改地址和模型；点「扫一下本机模型」自动填 `ollama list` 里的名字。

## 标签协议（System Prompt 已经写死了）

```
咋了||谁惹你了||说        → 三个气泡，一条条蹦
[STICKER:无语]            → 表情包气泡（名字必须和 IndexedDB 里的完全一致）
[DRAW:a girl eating noodles, anime style] → 生图气泡，英文描述
[QUICK:说说,不想说]        → 不显示成气泡，只换底部快捷回复
```

前端容错：`【】` 全角括号、`：` 全角冒号、`｜｜` 全角竖线都能认；认不出的表情包名字会退化成一句灰字，不会崩。

## 文件

```
礼貌小狗桌宠/
├─ main.py            # 窗口 / 托盘 / 热键 / 本地 HTTP 服务 / 代理 / 语音
├─ index.html         # 聊天 UI + 全部前端逻辑（单文件，无构建）
├─ memory_diary.txt   # 她的记忆，一行一件事，可直接编辑
├─ dog_girl.png       # 立绘（透明 PNG，同名替换）
├─ requirements.txt
└─ README.md
```

数据位置：`%APPDATA%\PolitePuppyPet\`（`pet.log`、`settings.json`、`webview2\`）。
设置环境变量 `POLITE_PUPPY_DATA=D:\somewhere` 可以改成便携模式。

## 为什么不会跨域

1. `main.py` 里起了一个只监听 `127.0.0.1` 的 `http.server`，把 `index.html`、`dog_girl.png`、`memory_diary.txt` 和 `/api/*` 一起发出去；
2. pywebview 加载的是 `http://127.0.0.1:端口/index.html`，不是 `file://`，所以 `fetch('/api/chat')` 是**同源请求**，浏览器根本不会发预检；
3. 代理层把请求转发给 `http://127.0.0.1:11434/v1/chat/completions`，SSE 用 chunked 原样透传，前端能一个字一个字收；
4. 真出现 `file://` 场景（比如你双击 html），`onAPIError` 会自动改调 `pywebview.api.chat()`，走 Python 内部 HTTP，同样没有跨域。

> 不要用 `localhost` 写地址：WebView2 有时解析到 `::1`，Ollama 只听 `127.0.0.1`，就会连不上。默认已经写成 `127.0.0.1`。

## 语音：为什么有两套

WebView2 是 Chromium，但**不带 Google 的语音后端**，`SpeechRecognition` 经常"存在但永远不返回结果"。

所以做了三级降级：

1. `SpeechRecognition`（`zh-CN`，`continuous + interimResults`，边说边出字）；
2. 3.5 秒没反应 / 报 `network` → 自动换 Windows 自带的 `System.Speech` 听写（`pywebview.api.voice_start` → 每 350ms `voice_poll` 拿增量）；
3. 都没有 → toast 提示"这台机器没有语音识别，打字吧"。

SAPI 需要系统装了中文语音包：设置 → 时间和语言 → 语言 → 中文 → 语音。

## 打包 exe

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

或：

```powershell
py -3.10 -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name PolitePuppy --icon dog_girl.ico ^
  --add-data "index.html;." --add-data "dog_girl.png;." --add-data "memory_diary.txt;." ^
  --collect-all pythonnet --collect-data webview --collect-binaries webview ^
  --hidden-import clr --hidden-import webview.platforms.winforms ^
  --hidden-import webview.platforms.edgechromium ^
  --hidden-import pystray._win32 --hidden-import pystray._util.win32 ^
  --exclude-module PyQt5 --exclude-module PyQt6 --exclude-module PySide2 --exclude-module PySide6 ^
  main.py
```

## 常见问题

**她说的话全是"嗯""哦"**
模型太小或者温度太低。换 `qwen2.5:7b` 以上，温度 0.85~0.95，最长回复 220 左右。

**一直不连**
`ollama serve` 开了吗？`curl http://127.0.0.1:11434/api/tags` 有东西吗？设置里模型名和 `ollama list` 一模一样吗？

**不发表情包**
设置 → 表情，先传图。System Prompt 里会把可用名字列出来，模型只用这些名字。名字对不上就发不出来。

**不主动找我**
只有真模型才会主动开腔（演示台词模式会显得很傻，所以关掉了）。另外窗口收起来时最多 20 分钟找你一次，省显卡。

**OneDrive 报 pythonnet 加载失败**
`main.py` 已经设了 `COMPLUS_LoadFromRemoteSources=1`。还不行就把整个目录挪到 `C:\PolitePuppy`。

**白屏**
装 [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/)，Win10/11 一般自带。
