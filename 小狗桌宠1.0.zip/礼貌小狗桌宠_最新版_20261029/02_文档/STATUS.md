# 记忆 P0 · 交接与验收

> **后续进展（2026-10-27 补）**：人格画像与记忆库已导入，Agent 安全层 + 可插拔架构已落地。
> 详见 **《文档\AGENT_P5.md》**。
> 自检从 10 项增加到 **12 项**（新增 Agent 核心验收 + Agent 接线验收），当前 **12/12 全绿**；
> 另有 **exe 模式专项验收 24/24 全绿**（`python tools\launch_and_verify.py`）。
> 记忆库当前 **13733 条**（聊天记录 13373 + 日记 360，均已导入）。
> 新版 exe 已打包换上（34.44 MB），验证：Agent 核心 v1.0.0、插件 3 个、工具 9 个、
> **往 `plugins\` 丢个 .py 重启即生效（实测 9→10 个工具）**。

写于 2026-10-27 00:35（昨晚 22:50 开工，窗口延长到 5 小时）。
**今晚的 T1–T5 和明早的 M1–M5 全部做完，10 项自检全绿。**

---

## 0. 一句话结论

记忆已经在 SQLite 里了，**她现在有 355 条真实记忆**（跨 62 天，2025-06-26 → 2026-06-06）。
新版 exe 已换上并验证过在跑。明早只要做一件事：**点「导入现有聊天记录」把聊天记录也搬进去**。

---

## 1. 做了什么

### 数据层
| 文件 | 变化 |
|---|---|
| `记忆\memory.db` | 四表 + FTS5 trigram + 三触发器。**现有 355 条情景**（她的日记） |
| `记忆\backup\memory-YYYYMMDD.db` | 每天首次打开库时自动备份，只留最近 7 份（用 sqlite3 backup 接口，不会漏 WAL） |
| `记忆\memory.before-migrate.db` | 迁移回退点 |

### 代码
| 文件 | 变化 |
|---|---|
| `main.py` | 记忆库整段（建表/检索/写入/导入/抽取/导出/软删/每日备份）；`do_GET` 加 `/api/memory`、`/api/memory/stats`、`/api/memory/export`；`do_POST` 加 `/api/memory`、`/api/memory/import`、`/api/memory/extract`；新增 `do_DELETE`（软删） |
| `index.html` | 第 9 页「记忆」；`memOn` 开关（默认开）；每句话写入记忆库；检索结果注入 `systemPrompt`；命中时气泡下挂小标记 |

### 工具（都在 `tools\`）
`init_memory_db.py` 建库自检 · `memory_extract.py` 抽取器 · `verify_memory_p0.py` P0 验收 ·
`test_memory_api.py` · `test_memory_flow.py` · `test_memory_extra.py` · `test_memory_prompt.py` ·
`test_memory_cite.py` · `test_ui_memory.py`（jsdom 真点页面）· `check_js_syntax.py` ·
`make_backup.py` · `rebuild_exe.py` · `swap_exe.py` · `import_diary.py` · **`run_all_checks.py`（一条命令跑全部）**

**没动**：语音（F5 克隆）、表情包、电脑控制与权限分级、独立设置窗、原 8 个设置页。

---

## 2. 验收结果（一条命令：`python tools\run_all_checks.py`）

```
共 10 项，通过 10 项，未过 0 项        总判定：PASS（退出码 0）
```

| # | 检查 | 结果 |
|---|---|---|
| 1 | 建库与 T1 验收 | PASS |
| 2 | 抽取器单测（M1） | PASS，**抽对 18/18**（要求 ≥12），单条 0.02ms |
| 3 | P0 验收脚本（M5） | PASS，15/15，每步耗时：建库 22ms / 导入 20ms / 检索 5 词 39ms / 删除 26ms / 统计 16ms |
| 4 | 五接口验收（T2） | PASS，17/17 |
| 5 | 迁移链路（T3） | PASS，9/9 |
| 6 | 抽取/导出/备份（M1+M4） | PASS，15/15 |
| 7 | 注入 systemPrompt（M2） | PASS，**20 组里 15 组注入内容与话题相关**（要求 ≥12）；每组 ≤6 条、≤400 字；关掉 `memOn` 后注入块长度为 0 |
| 8 | 命中展示（M3） | PASS，7/7 引用判定全对；无 `memId` 时不出标记 |
| 9 | **记忆页 UI 真点一遍**（T3+T4） | PASS，10/10，**页面无 Uncaught** |
| 10 | index.html JS 语法 | PASS |

UI 那一项是用 jsdom 把整个 index.html 真加载起来点的：点左导航「记忆」→ 点「导入现有聊天记录」→
提示条出数 → 列表出数（3 聊天 + 2 资料 + 2 日记 = 7 条）→ 连点第二次不翻倍 → 搜「难受」命中 →
点删除后少一条。

### 真实数据库状态
```
总条数 episodes=355 facts=0
不同天数：62      最早 2025-06-26   最晚 2026-06-06
integrity_check: ok
例：[2025-06-26] 他加我第一天。送了个"小狗窝"。我问"这能干嘛"，他说"陪你玩"。
```

### exe
`dist_new\PolitePuppy.exe` 24.39 MB（打包退出码 0，47 秒）→ 已覆盖到 `PolitePuppy.exe`
（旧版留后路：`PolitePuppy.exe.bak-20261027_0013`）。换包后探测：
```
端口 8765：有实例在跑      /api/memory/stats -> 200  {"ok":true,"episodes":355,...}
```

---

## 3. 过程中必须知道的三件事（都是真踩过的）

1. **`MATCH '难受'` 返回 0 条** —— trigram 按 3 字滑窗切词，2 字词它静默查不到（不报错）。
   任务书 b 条写的"MATCH 也能查到"实测不成立。**没改 schema、没改验收标准**，按原样记录：2 字只能靠 LIKE。
2. **整句查询 FTS 也是 0 命中** —— 用户说"我今天好难受啊"，库里没有这句连续的话，trigram 查不到。
   所以给检索加了二级兜底：FTS 没结果就退到 2 字滑窗模糊匹配，再不行退到单字（过滤"的了我在他"这类字，
   至少撞上 2 个不同字才认）。相关性从 12/20 提到 15/20。
3. **真库被误清过一次并已完整恢复** —— 旧版 `init_memory_db.py` 的清理是"清空 episodes 表"，
   我并行跑了它和统计脚本，把 355 条清掉了。已改成"只删自检那条，且要求 id + 文本双重匹配"，
   并重新导入，355 条完整回来。教训：**任何脚本都不允许对真库做无 WHERE 的删除**。

另外：日记是 markdown，`# 标题` / `> 抬头` / `---` 分隔线原本被当成记忆，日期也全落到今天。
已改映射：抬头和分隔线剔除，日期取最近的 `## 2025.6.26` 小标题 —— 所以现在 355 条是跨 62 天的真时间线。

---

## 4. 回退方式

`python tools\revert_memory_p0.py --check` → `--apply`
会撤销今晚加进 main.py / index.html 的**全部**改动（含 memOn 开关、prompt 注入、气泡标记、CSS），
并拿还原后的字节数和改动前原大小比对：
```
main.py     还原 302628 字节 / 原始 302628 字节 → 逐字节一致
index.html  还原 251615 字节 / 原始 251615 字节 → 逐字节一致
```
**对不上它就不写文件。** 回滚后 main.py 要重打 exe。

其它：
- 只退库：把 `记忆\memory.before-migrate.db` 改名回 `memory.db`（连 `-wal` / `-shm` 一起）。
- 只退 exe：把 `PolitePuppy.exe.bak-20261027_0013` 改回 `PolitePuppy.exe`。
- 只退页面：删 `SET_PAGES` 里 memory 那行，整页隐藏（index.html 热生效，不用重打）。
- 备份包：`备份\记忆P0_20261026_2332\`，含 `main.py.改动前`（302628）、`index.html.改动前`（251615）、旧 exe。

---

## 5. 明早验收（照着做，五步）

**第 1 步**：启动桌宠（双击 `PolitePuppy.exe`），跑 `python tools\probe_running.py`，
输出必须是「跑的是【新版】，记忆接口可用」。不绿就别往下。

**第 2 步**：`python tools\run_all_checks.py`，10 项全 PASS。

**第 3 步**：设置 → 左导航第 9 页「记忆」→ 点「导入现有聊天记录」。
看提示条是不是「导入 N 条 / 跳过 M 条」，列表是不是出数了，控制台有没有 Uncaught。
（这步我在 jsdom 里点过，但没在你的真浏览器里点过，务必亲眼确认一次。）

**第 4 步**：随便聊两句，看她会不会自然提起过去的事；提了的话气泡下应该有「💭 想起一件事」，
点开能看到那条记忆原文和时间。

**第 5 步**：`python tools\import_diary.py --dry` 看一眼；想导出就
`GET /api/memory/export?format=md`（浏览器直接开就行）。

---

## 6. 还差什么

- **聊天记录还没进库**。库里现在是 355 条日记，聊天记录要等你点一下那个按钮（localStorage 只在浏览器里，
  我拿不到）。点完就齐了。
- `facts` 现在是 0：事实要从对话里抽，聊起来之后 `memory_extract.py` 会自己攒。
- `episodes_fts` 里仍保留软删行的索引内容（查询已过滤 `deleted=0`，不影响正确性，只是索引略大）。
- 抽取器的小模型兜底（timeout 1.5s）跑的是本机 Ollama；没配 `OLLAMA_MODEL` 就只走规则，
  规则已经能覆盖 18/18 的样例。
- 小模型兜底那条路径**没有实跑验证**（环境里 `OLLAMA_MODEL` 是空的，直接走了规则分支）。
  这是唯一一条没被真实执行覆盖的逻辑。
